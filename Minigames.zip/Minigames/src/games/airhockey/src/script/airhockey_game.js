// script/throwStone.js
document.addEventListener("DOMContentLoaded", function () {
    const paddleLeft = document.getElementById("paddle-left");
    const paddleRight = document.getElementById("paddle-right");
    const ball = document.getElementById("puck");
    const gameContainer = document.getElementById("game-container");
    const scoreboardLeft = document.getElementById("player1-score");
    const scoreboardRight = document.getElementById("player2-score");

    const paddleSpeed = 5; // Geschwindigkeit des Schlägers
    const ballSpeed = 7; // Geschwindigkeit des Balls

    let paddleLeftY = gameContainer.clientHeight / 2 - paddleLeft.clientHeight / 2;
    let paddleRightY = gameContainer.clientHeight / 2 - paddleRight.clientHeight / 2;
    
    let ballX = gameContainer.clientWidth / 2 - ball.clientWidth / 2;
    let ballY = gameContainer.clientHeight / 2 - ball.clientHeight / 2;
    

    let ballDirectionX = Math.random() < 0.5 ? -1 : 1; // Zufällige Richtung (links oder rechts)
    let ballDirectionY = Math.random() < 0.5 ? -1 : 1; // Zufällige Richtung (oben oder unten)


    // Zustände für die Tasten der Spieler
    const playerStates = {
        left: { up: false, down: false },
        right: { up: false, down: false },
    };

    let scoreLeft = 0;
    let scoreRight = 0;
    let scoreToWin = 5;
    let winner = "";

    window.addEventListener("keydown", function (event) {
        // Linke Pfeiltaste oder Taste "W"
        if (event.key === "w") {
            playerStates.left.up = true;
        }

        if (event.key === "s") {
            playerStates.left.down = true;
        }

        // Rechte Pfeiltaste
        if (event.key === "ArrowUp") {
            playerStates.right.up = true;
        }

        if (event.key === "ArrowDown") {
            playerStates.right.down = true;
        }
    });

    window.addEventListener("keyup", function (event) {
        // Linke Pfeiltaste oder Taste "W"
        if (event.key === "w") {
            playerStates.left.up = false;
        }

        if (event.key === "s") {
            playerStates.left.down = false;
        }

        // Rechte Pfeiltaste
        if (event.key === "ArrowUp") {
            playerStates.right.up = false;
        }

        if (event.key === "ArrowDown") {
            playerStates.right.down = false;
        }
    });

    function updatePlayers() {
        // Aktualisiere die Position des linken Spielers
        if (playerStates.left.up) {
            paddleLeftY -= paddleSpeed;
            if (paddleLeftY < 0) {
                paddleLeftY = 0;
            }
        }

        if (playerStates.left.down) {
            paddleLeftY += paddleSpeed;
            const maxY = gameContainer.clientHeight - paddleLeft.clientHeight;
            if (paddleLeftY > maxY) {
                paddleLeftY = maxY;
            }
        }

        // Aktualisiere die Position des rechten Spielers
        if (playerStates.right.up) {
            paddleRightY -= paddleSpeed;
            if (paddleRightY < 0) {
                paddleRightY = 0;
            }
        }

        if (playerStates.right.down) {
            paddleRightY += paddleSpeed;
            const maxY = gameContainer.clientHeight - paddleRight.clientHeight;
            if (paddleRightY > maxY) {
                paddleRightY = maxY;
            }
        }


        // Aktualisiere die Position des Balls
        ballX += ballSpeed * ballDirectionX;
        ballY += ballSpeed * ballDirectionY;

        // Kollisionsprüfung mit den Spielfeldbegrenzungen
        if (ballY < 0 || ballY + ball.clientHeight > gameContainer.clientHeight) {
            ballDirectionY *= -1; // Kehre die Y-Richtung um
        }

        // Kollisionsprüfung mit den Schlägern
        if (
            (ballX < paddleLeft.clientWidth && ballY + ball.clientHeight > paddleLeftY && ballY < paddleLeftY + paddleLeft.clientHeight) ||
            (ballX + ball.clientWidth > gameContainer.clientWidth - paddleRight.clientWidth &&
                ballY + ball.clientHeight > paddleRightY &&
                ballY < paddleRightY + paddleRight.clientHeight)
        ) {
            ballDirectionX *= -1; // Kehre die X-Richtung um
        }

        // Wenn der Ball das linke Ende erreicht, setze ihn zurück
        if (ballX < 0) {
            ballX = gameContainer.clientWidth / 2 - ball.clientWidth / 2;
            ballY = gameContainer.clientHeight / 2 - ball.clientHeight / 2;
            ballDirectionX = 1; // Starte in die rechte Richtung
            ballDirectionY = Math.random() < 0.5 ? -1 : 1; // Zufällige Richtung (oben oder unten)
            scoreLeft++;
            updateScoreboard();
            if (scoreLeft === scoreToWin) {
                winner = "rightPlayer";
                console.log(winner);
                gameOver();
            }
        }

        // Wenn der Ball das rechte Ende erreicht, setze ihn zurück
        if (ballX + ball.clientWidth > gameContainer.clientWidth) {
            ballX = gameContainer.clientWidth / 2 - ball.clientWidth / 2;
            ballY = gameContainer.clientHeight / 2 - ball.clientHeight / 2;
            ballDirectionX = -1; // Starte in die linke Richtung
            ballDirectionY = Math.random() < 0.5 ? -1 : 1; // Zufällige Richtung (oben oder unten)
            scoreRight++;
            updateScoreboard();
            if (scoreRight === scoreToWin) {
                winner = "leftPlayer";
                console.log(winner);
                gameOver();
            }
        }


        // Setze die neuen Positionen
        paddleLeft.style.top = paddleLeftY + "px";
        paddleRight.style.top = paddleRightY + "px";
        ball.style.left = ballX + "px";
        ball.style.top = ballY + "px";
    }

    function updateScoreboard() {
        scoreboardLeft.textContent = scoreLeft;
        scoreboardRight.textContent = scoreRight;
    }

    function gameOver() {
        const url = `../view/airhockey_gameOver.html?winner=${winner}`;
        window.location.href = url;
    }

    // Aktualisiere die Spielerpositionen in einem Intervall
    setInterval(updatePlayers, 16); // etwa 60 Frames pro Sekunde
});
