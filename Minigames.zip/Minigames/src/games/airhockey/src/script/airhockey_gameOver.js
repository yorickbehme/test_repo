document.addEventListener("DOMContentLoaded", function () {
    const winnerSection = document.getElementById("winner-section");

    const urlParams = new URLSearchParams(window.location.search);
    const winner = urlParams.get('winner');
    console.log(winner);

    winnerSection.textContent = `Gewinner: ${winner}`;
});