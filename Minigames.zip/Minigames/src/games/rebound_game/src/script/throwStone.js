// script/throwStone.js

document.addEventListener("DOMContentLoaded", function () {
    const spaceship = document.getElementById("spaceship");
    const trampoline = document.getElementById("trampoline");
    const stonesContainer = document.getElementById("stones-container");
    const livesSpan = document.getElementById("lives");
    const levelSpan = document.getElementById("level");


    const stoneSpeed = 5; // Geschwindigkeit der Steine
    const maxLives = 20; // Maximale Anzahl der Leben

    let lives = maxLives;

    let level = 1;
    let levelUpInterval = 10000;
    let throwInterval = 2000;

    setInterval(levelUp, levelUpInterval);
    setInterval(throwStone, throwInterval);

    function throwStone() {
        const stone = createStone();
        stonesContainer.appendChild(stone);

        // Festlegen der Grundrichtung (nach unten)
        let baseDirectionX = 0;
        let baseDirectionY = 1;

        // Zufällige Abweichung von ±45 Grad
        const randomDeviation = (Math.random() - 0.5) * Math.PI / 4;

        // Berechnen der endgültigen Richtung
        let stoneDirectionX = baseDirectionX * Math.cos(randomDeviation) - baseDirectionY * Math.sin(randomDeviation);
        let stoneDirectionY = baseDirectionX * Math.sin(randomDeviation) + baseDirectionY * Math.cos(randomDeviation);

        let stoneX = spaceship.offsetLeft + spaceship.offsetWidth / 2 - stone.offsetWidth / 2;
        let stoneY = spaceship.offsetTop;

        function updateStone() {
            stoneX += stoneSpeed * stoneDirectionX;
            stoneY += stoneSpeed * stoneDirectionY;

            // Überprüfe, ob der Stein das Trampolin getroffen hat
            if (
                stoneY + stone.clientHeight > trampoline.offsetTop &&
                stoneX + stone.clientWidth > trampoline.offsetLeft &&
                stoneX < trampoline.offsetLeft + trampoline.offsetWidth
            ) {
                handleCollisionWithTrampoline();
            }

            // Wenn der Stein den Boden erreicht hat
            if (stoneY + stone.clientHeight > window.innerHeight) {
                // Stein hat den Boden erreicht (verloren)
                stone.remove();
                lives--;

                // Aktualisiere die Lebensanzeige
                livesSpan.textContent = lives;

                // Überprüfe auf Spielende
                if (lives === 0) {
                    endGame();
                }
            } else {
                // Stein ist noch in der Luft
                stone.style.left = stoneX + "px";
                stone.style.top = stoneY + "px";
                requestAnimationFrame(updateStone);
            }
        }

            function handleCollisionWithTrampoline() {
                // Setze die Richtung des Steins auf eine feste Richtung nach oben
                stoneDirectionX = 0;
                stoneDirectionY = -1;

                stoneX = stone.offsetLeft;
                stoneY = trampoline.offsetTop - stone.clientHeight;

                stone.style.backgroundColor = "blue";
            }

            // Starte die Aktualisierung des Steins
            updateStone();
    }

    function createStone() {
        const stone = document.createElement("div");
        stone.className = "stone";
        return stone;
    }

    function levelUp(){
        level++;

        // Aktualisiere die Levelanzeige
        levelSpan.textContent = level;

        throwInterval = throwInterval * 0.9;
    }

    function endGame() {
        const url = `../view/rebound_gameOver.html`;
        window.location.href = url;
        console.log("Spiel beendet!");
    }
});
