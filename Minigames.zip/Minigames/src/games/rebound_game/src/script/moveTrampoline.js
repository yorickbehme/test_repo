document.addEventListener("DOMContentLoaded", function () {
    const trampoline = document.getElementById("trampoline");
    const trampolineSpeed = 5; // Geschwindigkeit des Trampolins

    // Zustand für die Tasten der Spieler
    const playerState = { up: false, down: false };

    window.addEventListener("keydown", function (event) {
        // Linke Pfeiltaste
        if (event.key === "ArrowLeft") {
            playerState.up = true;
        }

        if (event.key === "ArrowRight") {
            playerState.down = true;
        }
    });

    window.addEventListener("keyup", function (event) {
        // Linke Pfeiltaste
        if (event.key === "ArrowLeft") {
            playerState.up = false;
        }

        if (event.key === "ArrowRight") {
            playerState.down = false;
        }
    });

    function updateTrampoline() {
        // Aktualisiere die Position des Trampolins
        if (playerState.up) {
            trampoline.style.left = trampoline.offsetLeft - trampolineSpeed + "px";
        }

        if (playerState.down) {
            trampoline.style.left = trampoline.offsetLeft + trampolineSpeed + "px";
        }

        // Begrenze die Bewegung innerhalb des Spielbereichs
        const maxX = window.innerWidth - trampoline.offsetWidth;
        trampoline.style.left = Math.max(0, Math.min(trampoline.offsetLeft, maxX)) + "px";
    }

    // Aktualisiere die Trampolinposition in einem Intervall
    setInterval(updateTrampoline, 16); // etwa 60 Frames pro Sekunde
});
